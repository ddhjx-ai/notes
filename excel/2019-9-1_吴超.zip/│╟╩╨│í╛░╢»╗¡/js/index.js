$(function  () {
	var time = 0;
	setInterval(function(){
		time++;
		if((time%60 - 53) === 0){
			$('body').removeClass('bg');
			$('.stars').removeClass('shan');
			$('.heavens>img:first-child').addClass('sun');
			$('.heavens>img:last-child').removeClass('moon');
			$('.houses').removeClass('meng');
		}else if((time%30 -23) === 0) {
			$('body').addClass('bg');
			$('.stars').addClass('shan');
			$('.heavens>img:last-child').addClass('moon');
			$('.heavens>img:first-child').removeClass('sun');
			$('.houses').addClass('meng');

		}
	},1000);
	timeId = setInterval(function(){
		$('.stars img').remove();
		for(var i = 0; i < 15; i++){
			var num1 = parseInt(Math.random()*1500 + 10);
			var num2 = parseInt(Math.random()*380 +10);
			var type = parseInt( Math.random()*2+1);
			console.log(num1,num2,type)
			var $img = $('<img src="images/star'+ type +'.png">');
			$img.css({
				left: num1,
				top : num2
			});
			$('.stars').append($img);
		}
	},500)
})