$(function () {
	// 初始化 js
	$('#fullpage').fullpage({
		// 配置参数：
		// 显示项目导航
		navigation:true, 				
		// 设置颜色
		sectionsColor:["#fadd67", "#84a2d4", "#ef674d", "#ffeedd", "#d04759", "#84d9ed", "#8ac060"],
		// 设置内容不垂直居中				
		verticalCentered:false, 
		// 设置滚动速度		
		scrollingSpeed:1000,

		// 滚动到某一屏后的回调函数,这里的index是从 1 开始计算的
		afterLoad:function (link,index) {
			$('.section').eq(index-1).addClass('now');
		},
		// 离开某一屏的回调函数
		onLeave:function(index,nextIndex,direction){
			$('.section').eq(index-1).addClass('leaved');
			if(index === 5 && nextIndex === 6){
				$('.screen_6 .box').addClass('show')
			}
		},

		// 页面结构生成后的回调函数，或者说页面初始化完成后的回调函数
		afterRender:function(){
			// 点击进入下一页面
			$('.more').on('click',function(){
				$.fn.fullpage.moveSectionDown();
			})

			// 
			$('.screen_8').find('.content').on('mousemove',(function(event) {
				$(this).find('.hand').css({
					top:event.pageY-80,
					left:event.pageX-380
				});
			})).find('.again').on('click',function(){
				$.fn.fullpage.moveTo(1);
				$('.show,.leaved,.now').removeClass('show').removeClass('leaved').removeClass('now');
			});

			
			$('.screen_8 .btn img:first-child').hover(function() {
				$(this).css({
					opacity:0
				})
			}, function() {
				$(this).css({
					opacity:1
				})
			});
		}

	});
})
